﻿
namespace bartusarchitektury
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.XCHGL = new System.Windows.Forms.Button();
            this.MOVL = new System.Windows.Forms.Button();
            this.ComboLR = new System.Windows.Forms.ComboBox();
            this.ComboLL = new System.Windows.Forms.ComboBox();
            this.DXtextbox = new System.Windows.Forms.TextBox();
            this.CXtextbox = new System.Windows.Forms.TextBox();
            this.BXtextbox = new System.Windows.Forms.TextBox();
            this.AXtextbox = new System.Windows.Forms.TextBox();
            this.DXvalue = new System.Windows.Forms.Label();
            this.CXvalue = new System.Windows.Forms.Label();
            this.BXvalue = new System.Windows.Forms.Label();
            this.AXvalue = new System.Windows.Forms.Label();
            this.DXlabel = new System.Windows.Forms.Label();
            this.CXlabel = new System.Windows.Forms.Label();
            this.BXlabel = new System.Windows.Forms.Label();
            this.AXlabel = new System.Windows.Forms.Label();
            this.ResetButton = new System.Windows.Forms.Button();
            this.RandomButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // XCHGL
            // 
            this.XCHGL.Location = new System.Drawing.Point(160, 265);
            this.XCHGL.Name = "XCHGL";
            this.XCHGL.Size = new System.Drawing.Size(94, 29);
            this.XCHGL.TabIndex = 269;
            this.XCHGL.Text = "XCHG";
            this.XCHGL.UseVisualStyleBackColor = true;
            this.XCHGL.Click += new System.EventHandler(this.XCHGL_Click);
            // 
            // MOVL
            // 
            this.MOVL.Location = new System.Drawing.Point(12, 265);
            this.MOVL.Name = "MOVL";
            this.MOVL.Size = new System.Drawing.Size(94, 29);
            this.MOVL.TabIndex = 268;
            this.MOVL.Text = "MOV";
            this.MOVL.UseVisualStyleBackColor = true;
            this.MOVL.Click += new System.EventHandler(this.MOVL_Click);
            // 
            // ComboLR
            // 
            this.ComboLR.FormattingEnabled = true;
            this.ComboLR.Items.AddRange(new object[] {
            "AX",
            "BX",
            "CX",
            "DX"});
            this.ComboLR.Location = new System.Drawing.Point(164, 218);
            this.ComboLR.Name = "ComboLR";
            this.ComboLR.Size = new System.Drawing.Size(50, 28);
            this.ComboLR.TabIndex = 267;
            // 
            // ComboLL
            // 
            this.ComboLL.FormattingEnabled = true;
            this.ComboLL.Items.AddRange(new object[] {
            "AX",
            "BX",
            "CX",
            "DX"});
            this.ComboLL.Location = new System.Drawing.Point(56, 218);
            this.ComboLL.Name = "ComboLL";
            this.ComboLL.Size = new System.Drawing.Size(50, 28);
            this.ComboLL.TabIndex = 266;
            // 
            // DXtextbox
            // 
            this.DXtextbox.Location = new System.Drawing.Point(172, 174);
            this.DXtextbox.MaxLength = 4;
            this.DXtextbox.Name = "DXtextbox";
            this.DXtextbox.Size = new System.Drawing.Size(90, 27);
            this.DXtextbox.TabIndex = 265;
            this.DXtextbox.Text = "0000";
            this.DXtextbox.TextChanged += new System.EventHandler(this.DXtextbox_TextChanged);
            // 
            // CXtextbox
            // 
            this.CXtextbox.Location = new System.Drawing.Point(172, 138);
            this.CXtextbox.MaxLength = 4;
            this.CXtextbox.Name = "CXtextbox";
            this.CXtextbox.Size = new System.Drawing.Size(90, 27);
            this.CXtextbox.TabIndex = 264;
            this.CXtextbox.Text = "0000";
            this.CXtextbox.TextChanged += new System.EventHandler(this.CXtextbox_TextChanged);
            // 
            // BXtextbox
            // 
            this.BXtextbox.Location = new System.Drawing.Point(172, 97);
            this.BXtextbox.MaxLength = 4;
            this.BXtextbox.Name = "BXtextbox";
            this.BXtextbox.Size = new System.Drawing.Size(90, 27);
            this.BXtextbox.TabIndex = 263;
            this.BXtextbox.Text = "0000";
            this.BXtextbox.TextChanged += new System.EventHandler(this.BXtextbox_TextChanged);
            // 
            // AXtextbox
            // 
            this.AXtextbox.Location = new System.Drawing.Point(172, 60);
            this.AXtextbox.MaxLength = 4;
            this.AXtextbox.Name = "AXtextbox";
            this.AXtextbox.Size = new System.Drawing.Size(90, 27);
            this.AXtextbox.TabIndex = 262;
            this.AXtextbox.Text = "0000";
            this.AXtextbox.TextChanged += new System.EventHandler(this.AXtextbox_TextChanged);
            // 
            // DXvalue
            // 
            this.DXvalue.BackColor = System.Drawing.SystemColors.ControlDark;
            this.DXvalue.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DXvalue.Location = new System.Drawing.Point(63, 174);
            this.DXvalue.Name = "DXvalue";
            this.DXvalue.Size = new System.Drawing.Size(90, 25);
            this.DXvalue.TabIndex = 261;
            this.DXvalue.Text = "0000";
            this.DXvalue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CXvalue
            // 
            this.CXvalue.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CXvalue.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CXvalue.Location = new System.Drawing.Point(64, 137);
            this.CXvalue.Name = "CXvalue";
            this.CXvalue.Size = new System.Drawing.Size(90, 25);
            this.CXvalue.TabIndex = 260;
            this.CXvalue.Text = "0000";
            this.CXvalue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BXvalue
            // 
            this.BXvalue.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BXvalue.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BXvalue.Location = new System.Drawing.Point(64, 97);
            this.BXvalue.Name = "BXvalue";
            this.BXvalue.Size = new System.Drawing.Size(90, 25);
            this.BXvalue.TabIndex = 259;
            this.BXvalue.Text = "0000";
            this.BXvalue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AXvalue
            // 
            this.AXvalue.BackColor = System.Drawing.SystemColors.ControlDark;
            this.AXvalue.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AXvalue.Location = new System.Drawing.Point(64, 62);
            this.AXvalue.Name = "AXvalue";
            this.AXvalue.Size = new System.Drawing.Size(90, 25);
            this.AXvalue.TabIndex = 258;
            this.AXvalue.Text = "0000";
            this.AXvalue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DXlabel
            // 
            this.DXlabel.AutoSize = true;
            this.DXlabel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DXlabel.Location = new System.Drawing.Point(11, 174);
            this.DXlabel.Name = "DXlabel";
            this.DXlabel.Size = new System.Drawing.Size(35, 25);
            this.DXlabel.TabIndex = 256;
            this.DXlabel.Text = "DX";
            // 
            // CXlabel
            // 
            this.CXlabel.AutoSize = true;
            this.CXlabel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CXlabel.Location = new System.Drawing.Point(11, 137);
            this.CXlabel.Name = "CXlabel";
            this.CXlabel.Size = new System.Drawing.Size(35, 25);
            this.CXlabel.TabIndex = 255;
            this.CXlabel.Text = "CX";
            // 
            // BXlabel
            // 
            this.BXlabel.AutoSize = true;
            this.BXlabel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BXlabel.Location = new System.Drawing.Point(12, 97);
            this.BXlabel.Name = "BXlabel";
            this.BXlabel.Size = new System.Drawing.Size(34, 25);
            this.BXlabel.TabIndex = 254;
            this.BXlabel.Text = "BX";
            // 
            // AXlabel
            // 
            this.AXlabel.AutoSize = true;
            this.AXlabel.BackColor = System.Drawing.SystemColors.Control;
            this.AXlabel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AXlabel.Location = new System.Drawing.Point(12, 62);
            this.AXlabel.Name = "AXlabel";
            this.AXlabel.Size = new System.Drawing.Size(35, 25);
            this.AXlabel.TabIndex = 253;
            this.AXlabel.Text = "AX";
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(63, 12);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(90, 29);
            this.ResetButton.TabIndex = 252;
            this.ResetButton.Text = "reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // RandomButton
            // 
            this.RandomButton.Location = new System.Drawing.Point(172, 12);
            this.RandomButton.Name = "RandomButton";
            this.RandomButton.Size = new System.Drawing.Size(90, 29);
            this.RandomButton.TabIndex = 257;
            this.RandomButton.Text = "random";
            this.RandomButton.UseVisualStyleBackColor = true;
            this.RandomButton.Click += new System.EventHandler(this.RandomButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 324);
            this.Controls.Add(this.XCHGL);
            this.Controls.Add(this.MOVL);
            this.Controls.Add(this.ComboLR);
            this.Controls.Add(this.ComboLL);
            this.Controls.Add(this.DXtextbox);
            this.Controls.Add(this.CXtextbox);
            this.Controls.Add(this.BXtextbox);
            this.Controls.Add(this.AXtextbox);
            this.Controls.Add(this.DXvalue);
            this.Controls.Add(this.CXvalue);
            this.Controls.Add(this.BXvalue);
            this.Controls.Add(this.AXvalue);
            this.Controls.Add(this.RandomButton);
            this.Controls.Add(this.DXlabel);
            this.Controls.Add(this.CXlabel);
            this.Controls.Add(this.BXlabel);
            this.Controls.Add(this.AXlabel);
            this.Controls.Add(this.ResetButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button XCHGL;
        private System.Windows.Forms.Button MOVL;
        private System.Windows.Forms.ComboBox ComboLR;
        private System.Windows.Forms.ComboBox ComboLL;
        private System.Windows.Forms.TextBox DXtextbox;
        private System.Windows.Forms.TextBox CXtextbox;
        private System.Windows.Forms.TextBox BXtextbox;
        private System.Windows.Forms.TextBox AXtextbox;
        private System.Windows.Forms.Label DXvalue;
        private System.Windows.Forms.Label CXvalue;
        private System.Windows.Forms.Label BXvalue;
        private System.Windows.Forms.Label AXvalue;
        private System.Windows.Forms.Label DXlabel;
        private System.Windows.Forms.Label CXlabel;
        private System.Windows.Forms.Label BXlabel;
        private System.Windows.Forms.Label AXlabel;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button RandomButton;
    }
}

