﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bartusarchitektury
{
    public partial class Form1 : Form
    {
        protected Random rand = new Random();


        public Form1()
        {
            InitializeComponent();
        }



        //Reset button
        private void ResetButton_Click(object sender, EventArgs e)
        {
            AXvalue.Text = "0000";
            BXvalue.Text = "0000";
            CXvalue.Text = "0000";
            DXvalue.Text = "0000";
        }



        //Random button
        private void RandomButton_Click(object sender, EventArgs e)
        {
            AXvalue.Text = "";
            BXvalue.Text = "";
            CXvalue.Text = "";
            DXvalue.Text = "";

            for (int i = 0; i < 4; i++)
            {
                if (rand.Next(1, 3) == 1)
                    AXvalue.Text += Convert.ToString(rand.Next(0, 10));
                else
                    AXvalue.Text += (char)('A' + rand.Next(0, 6));
            }

            for (int i = 0; i < 4; i++)
            {
                if (rand.Next(1, 3) == 1)
                    BXvalue.Text += Convert.ToString(rand.Next(0, 10));
                else
                    BXvalue.Text += (char)('A' + rand.Next(0, 6));
            }

            for (int i = 0; i < 4; i++)
            {
                if (rand.Next(1, 3) == 1)
                    CXvalue.Text += Convert.ToString(rand.Next(0, 10));
                else
                    CXvalue.Text += (char)('A' + rand.Next(0, 6));
            }

            for (int i = 0; i < 4; i++)
            {
                if (rand.Next(1, 3) == 1)
                    DXvalue.Text += Convert.ToString(rand.Next(0, 10));
                else
                    DXvalue.Text += (char)('A' + rand.Next(0, 6));
            }
        }



        //TextBox blokada wprowadzania byle czego
        private void AXtextbox_TextChanged(object sender, EventArgs e)
        {
            foreach (char x in AXtextbox.Text)
            {
                if (x == 'A' || x == 'B' || x == 'C' || x == 'D' || x == 'E' || x == 'F' || x == '0' || x == '1' || x == '2' || x == '3' || x == '4' || x == '5' || x == '6' || x == '7' || x == '8' || x == '9') { AXvalue.Text = AXtextbox.Text; }
                else
                {
                    MessageBox.Show("Błędnie wprowadzone dane!");
                    AXtextbox.Text = "";
                    AXvalue.Text = "";
                }
            }
        }

        private void BXtextbox_TextChanged(object sender, EventArgs e)
        {
            foreach (char x in BXtextbox.Text)
            {
                if (x == 'A' || x == 'B' || x == 'C' || x == 'D' || x == 'E' || x == 'F' || x == '0' || x == '1' || x == '2' || x == '3' || x == '4' || x == '5' || x == '6' || x == '7' || x == '8' || x == '9') { BXvalue.Text = BXtextbox.Text; }
                else
                {
                    MessageBox.Show("Błędnie wprowadzone dane!");
                    BXtextbox.Text = "";
                    BXvalue.Text = "";
                }
            }
        }

        private void CXtextbox_TextChanged(object sender, EventArgs e)
        {
            foreach (char x in CXtextbox.Text)
            {
                if (x == 'A' || x == 'B' || x == 'C' || x == 'D' || x == 'E' || x == 'F' || x == '0' || x == '1' || x == '2' || x == '3' || x == '4' || x == '5' || x == '6' || x == '7' || x == '8' || x == '9') { CXvalue.Text = CXtextbox.Text; }
                else
                {
                    MessageBox.Show("Błędnie wprowadzone dane!");
                    CXtextbox.Text = "";
                    CXvalue.Text = "";
                }
            }
        }

        private void DXtextbox_TextChanged(object sender, EventArgs e)
        {
            foreach (char x in DXtextbox.Text)
            {
                if (x == 'A' || x == 'B' || x == 'C' || x == 'D' || x == 'E' || x == 'F' || x == '0' || x == '1' || x == '2' || x == '3' || x == '4' || x == '5' || x == '6' || x == '7' || x == '8' || x == '9') { DXvalue.Text = DXtextbox.Text; }
                else
                {
                    MessageBox.Show("Błędnie wprowadzone dane!");
                    DXtextbox.Text = "";
                    DXvalue.Text = "";
                }
            }
        }

        private void MOVL_Click(object sender, EventArgs e)
        {
            //MOV AX
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "BX")
                BXvalue.Text = AXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "CX")
                CXvalue.Text = AXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "DX")
                DXvalue.Text = AXvalue.Text;

            //MOV BX
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "AX")
                AXvalue.Text = BXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "CX")
                CXvalue.Text = BXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "DX")
                DXvalue.Text = BXvalue.Text;

            //MOV CX
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "AX")
                AXvalue.Text = CXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "BX")
                BXvalue.Text = CXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "DX")
                DXvalue.Text = CXvalue.Text;

            //MOV DX
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "AX")
                AXvalue.Text = DXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "BX")
                BXvalue.Text = DXvalue.Text;
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "CX")
                CXvalue.Text = DXvalue.Text;
        }

        private void XCHGL_Click(object sender, EventArgs e)
        {
            //XCHG AX
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "BX")
            {
                string napis = BXvalue.Text;
                BXvalue.Text = AXvalue.Text;
                AXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "CX")
            {
                string napis = CXvalue.Text;
                CXvalue.Text = AXvalue.Text;
                AXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "AX" && ComboLR.SelectedItem.ToString() == "DX")
            {
                string napis = DXvalue.Text;
                DXvalue.Text = AXvalue.Text;
                AXvalue.Text = napis;
            }

            //XCHG BX
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "AX")
            {
                string napis = AXvalue.Text;
                AXvalue.Text = BXvalue.Text;
                BXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "CX")
            {
                string napis = CXvalue.Text;
                CXvalue.Text = BXvalue.Text;
                BXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "BX" && ComboLR.SelectedItem.ToString() == "DX")
            {
                string napis = DXvalue.Text;
                DXvalue.Text = BXvalue.Text;
                BXvalue.Text = napis;
            }

            //XCHG CX
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "AX")
            {
                string napis = AXvalue.Text;
                AXvalue.Text = CXvalue.Text;
                CXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "BX")
            {
                string napis = BXvalue.Text;
                BXvalue.Text = CXvalue.Text;
                CXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "CX" && ComboLR.SelectedItem.ToString() == "DX")
            {
                string napis = DXvalue.Text;
                DXvalue.Text = CXvalue.Text;
                CXvalue.Text = napis;
            }

            //XCHG DX
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "AX")
            {
                string napis = AXvalue.Text;
                AXvalue.Text = DXvalue.Text;
                DXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "BX")
            {
                string napis = BXvalue.Text;
                BXvalue.Text = DXvalue.Text;
                DXvalue.Text = napis;
            }
            if (ComboLL.SelectedItem.ToString() == "DX" && ComboLR.SelectedItem.ToString() == "CX")
            {
                string napis = CXvalue.Text;
                CXvalue.Text = DXvalue.Text;
                DXvalue.Text = napis;
            }
        }
    }
}
